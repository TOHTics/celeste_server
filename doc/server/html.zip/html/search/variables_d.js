var searchData=
[
  ['v',['v',['../structsunspec_1_1data_1_1_sun_spec_data.html#aeb1d272c4563689a07b64fa2a41f0465',1,'sunspec::data::SunSpecData']]],
  ['value',['value',['../structsunspec_1_1data_1_1_point_data.html#a669ad65a5985a90717b48a89bf5efe26',1,'sunspec::data::PointData']]]
];
