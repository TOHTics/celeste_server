var searchData=
[
  ['model_5flist_5ftype',['model_list_type',['../structsunspec_1_1data_1_1_device_data.html#a35392620b4aa510eb8dff6f84d7aaaca',1,'sunspec::data::DeviceData']]]
];
