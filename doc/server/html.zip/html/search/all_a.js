var searchData=
[
  ['ns',['ns',['../structsunspec_1_1data_1_1_device_data.html#a62d4f6006c84bd7d9217b24e3755b979',1,'sunspec::data::DeviceData::ns()'],['../structsunspec_1_1data_1_1_model_data.html#a54021b21444d4966e6d2fdceb67f95c8',1,'sunspec::data::ModelData::ns()']]]
];
