var searchData=
[
  ['lid',['lid',['../structsunspec_1_1data_1_1_device_data.html#abd4b73d94180a81a250c7e7bbf0f45c7',1,'sunspec::data::DeviceData']]],
  ['limit_5fexceeded',['LIMIT_EXCEEDED',['../status__code_8hpp.html#a21f1f2d9b691c3059a7752ea94c64dae',1,'sunspec::sdx']]]
];
