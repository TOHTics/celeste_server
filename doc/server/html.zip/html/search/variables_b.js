var searchData=
[
  ['t',['t',['../structsunspec_1_1data_1_1_device_data.html#aace034fae7cf144b9b38d0dfc50d18ac',1,'sunspec::data::DeviceData::t()'],['../structsunspec_1_1data_1_1_point_data.html#ab8da416982508faabd9ac09ab407bc5f',1,'sunspec::data::PointData::t()']]]
];
