var searchData=
[
  ['xmlerror',['XMLError',['../classsunspec_1_1data_1_1_x_m_l_error.html',1,'sunspec::data']]]
];
