var searchData=
[
  ['verify_5fpoint',['verify_point',['../verify_8cpp.html#aafb4ec1d943b727c1c891699974c092a',1,'sunspec::data::verifier']]]
];
