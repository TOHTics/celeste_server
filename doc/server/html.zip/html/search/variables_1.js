var searchData=
[
  ['cid',['cid',['../structsunspec_1_1data_1_1_device_data.html#a1056f73011728513747a96e31fa9ddc0',1,'sunspec::data::DeviceData']]],
  ['code',['code',['../structsunspec_1_1data_1_1_device_result.html#a1aa6390f5caadc517ea847def7074853',1,'sunspec::data::DeviceResult::code()'],['../structsunspec_1_1data_1_1_sun_spec_data_response.html#a64e6052d8d4d446c4ba4bb750dd127cc',1,'sunspec::data::SunSpecDataResponse::code()']]]
];
