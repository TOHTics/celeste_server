var searchData=
[
  ['database_20configuration',['Database Configuration',['../md_doc__d_b.html',1,'']]]
];
