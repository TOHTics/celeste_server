var searchData=
[
  ['x',['x',['../structsunspec_1_1data_1_1_model_data.html#aee92cb69fbb04a963237f171571e806c',1,'sunspec::data::ModelData::x()'],['../structsunspec_1_1data_1_1_point_data.html#a5c7544aa90af8105a9fe0571518f474a',1,'sunspec::data::PointData::x()']]]
];
