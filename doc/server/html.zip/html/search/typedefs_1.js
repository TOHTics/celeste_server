var searchData=
[
  ['device_5flist_5ftype',['device_list_type',['../structsunspec_1_1data_1_1_sun_spec_data.html#a104b19b0bddeb33e5937e937e9e0b72d',1,'sunspec::data::SunSpecData']]],
  ['device_5fresult_5flist',['device_result_list',['../structsunspec_1_1data_1_1_sun_spec_data_response.html#a4474b2f577a11dbe97247dbf5ee580bd',1,'sunspec::data::SunSpecDataResponse']]]
];
