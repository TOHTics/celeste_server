var searchData=
[
  ['todayreadrequest',['TodayReadRequest',['../structceleste_1_1resource_1_1_today_read_request.html',1,'celeste::resource']]]
];
