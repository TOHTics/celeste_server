var searchData=
[
  ['reason',['reason',['../structsunspec_1_1data_1_1_device_result.html#a4ece3ae37ea1155cbde18fba6b0aeb49',1,'sunspec::data::DeviceResult::reason()'],['../structsunspec_1_1data_1_1_sun_spec_data_response.html#a1f59158d99d2075196a39d569df77a42',1,'sunspec::data::SunSpecDataResponse::reason()']]]
];
